package com.company.room;

import androidx.fragment.app.Fragment;

public class RecyclerBuscarFragment extends Fragment {
}